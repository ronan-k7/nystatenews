import { getSortedNews } from "../src/utils/news";

const news = getSortedNews();
console.log("Total articles:", news.length);
console.log("Top 10 articles (Date and Category):");
news.slice(0, 10).forEach((a, i) => {
  console.log(`${i+1}. [${a.date}] [${a.category}] - ${a.title}`);
});

const categories = [...new Set(news.map(a => a.category))];
console.log("Categories found:", categories.join(", "));
